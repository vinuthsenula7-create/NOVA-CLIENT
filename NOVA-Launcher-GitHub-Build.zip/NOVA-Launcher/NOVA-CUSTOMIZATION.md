# NOVA Launcher customization

This source tree is a customized fork of Prism Launcher. The application branding and built-in dark-theme accent palette have been changed to NOVA Launcher. The underlying launcher functionality and upstream notices are retained.

Prism Launcher source code is licensed under GPL-3.0-only. When distributing binaries, provide the corresponding source code and preserve all applicable copyright and license notices. The original Prism Launcher logo is not reused as the NOVA logo.

This fork continues to use Prism Launcher's metadata and service endpoints where required for compatibility. It is not an official Prism Launcher release and is not affiliated with the Prism Launcher project.
