// SPDX-FileCopyrightText: 2022 flowln <flowlnlnln@gmail.com>
//
// SPDX-License-Identifier: GPL-3.0-only

#include "ManagedPackPage.h"
#include <QDesktopServices>
#include <QLineEdit>
#include <QUrl>
#include <QUrlQuery>
#include "modplatform/ModIndex.h"
#include "ui_ManagedPackPage.h"

#include <QAbstractItemView>
#include <QFileDialog>
#include <QInputDialog>
#include <memory>

#include "Application.h"
#include "InstanceImportTask.h"
#include "InstanceList.h"
#include "InstanceTask.h"
#include "Markdown.h"
#include "StringUtils.h"

#include "ui/InstanceWindow.h"
#include "ui/dialogs/CustomMessageBox.h"
#include "ui/dialogs/ProgressDialog.h"

ManagedPackPage* ManagedPackPage::createPage(BaseInstance* inst, const QString& type, QWidget* parent)
{
    if (type == "modrinth") {
        return new ModrinthManagedPackPage(inst, nullptr, parent);
    }
    if (type == "flame" && ((APPLICATION->capabilities() & Application::SupportsFlame) != 0U)) {
        return new FlameManagedPackPage(inst, nullptr, parent);
    }

    return new GenericManagedPackPage(inst, nullptr, parent);
}

ManagedPackPage::ManagedPackPage(BaseInstance* inst, InstanceWindow* instanceWindow, QWidget* parent)
    : QWidget(parent), m_instanceWindow(instanceWindow), ui(new Ui::ManagedPackPage), m_inst(inst)
{
    Q_ASSERT(inst);

    ui->setupUi(this);

    ui->versionsComboBox->view()->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
    ui->versionsComboBox->view()->setVerticalScrollMode(QAbstractItemView::ScrollPerPixel);

    ui->reloadButton->setVisible(false);
    connect(ui->reloadButton, &QPushButton::clicked, this, [this](bool) {
        ui->reloadButton->setVisible(false);

        m_loaded = false;
        // Pretend we're opening the page again
        openedImpl();
    });

    connect(ui->changelogTextBrowser, &QTextBrowser::anchorClicked, this, [](const QUrl& url) {
        if (url.scheme().isEmpty()) {
            auto querry =
                QUrlQuery(url.query()).queryItemValue("remoteUrl", QUrl::FullyDecoded);  // curseforge workaround for linkout?remoteUrl=
            auto decoded = QUrl::fromPercentEncoding(querry.toUtf8());
            auto newUrl = QUrl(decoded);
            if (newUrl.isValid() && (newUrl.scheme() == "http" || newUrl.scheme() == "https")) {
                QDesktopServices ::openUrl(newUrl);
            }
            return;
        }
        QDesktopServices::openUrl(url);
    });

    connect(ui->urlLine, &QLineEdit::textChanged, this,
            [this](const QString& text) { m_inst->settings()->set("ManagedPackURL", text.trimmed()); });

    connect(ui->updateFromUrlButton, &QPushButton::clicked, this, &ManagedPackPage::updateFromUrl);
}

ManagedPackPage::~ManagedPackPage()
{
    delete ui;
}

void ManagedPackPage::openedImpl()
{
    if (m_inst->getManagedPackID().isEmpty()) {
        ui->packVersion->hide();
        ui->packVersionLabel->hide();
        ui->packOrigin->hide();
        ui->packOriginLabel->hide();
        ui->versionsComboBox->hide();
        // the URL line edit already covers this for local packs
        ui->updateFromUrlButton->hide();
        ui->updateToVersionLabel->setText(tr("URL:"));
        ui->updateButton->setText(tr("Update Pack"));
        ui->updateButton->setDisabled(false);
        ui->urlLine->setText(m_inst->settings()->get("ManagedPackURL").toString().trimmed());

        ui->packName->setText(m_inst->name());
        ui->changelogTextBrowser->setText(tr("This is a local modpack.\n"
                                             "This can be updated either using a file in %1 format or an URL.\n"
                                             "Do not use a different format than the one mentioned as it may break the instance.\n"
                                             "Make sure you also trust the URL.\n")
                                              .arg(displayName()));
        return;
    }
    ui->urlLine->hide();
    ui->packName->setText(m_inst->getManagedPackName());
    ui->packVersion->setText(m_inst->getManagedPackVersionName());
    ui->packOrigin->setText(tr("Website: <a href=%1>%2</a>    |    Pack ID: %3    |    Version ID: %4")
                                .arg(url(), displayName(), m_inst->getManagedPackID(), m_inst->getManagedPackVersionID()));

    parseManagedPack();
}

QString ManagedPackPage::displayName() const
{
    auto type = m_inst->getManagedPackType();
    if (type.isEmpty()) {
        return {};
    }
    if (type == "flame") {
        type = "CurseForge";
    }
    return type.replace(0, 1, type[0].toUpper());
}

QIcon ManagedPackPage::icon() const
{
    return QIcon::fromTheme(m_inst->getManagedPackType());
}

QString ManagedPackPage::helpPage() const
{
    return {};
}

void ManagedPackPage::retranslate()
{
    ui->retranslateUi(this);
}

bool ManagedPackPage::shouldDisplay() const
{
    return m_inst->isManagedPack();
}

bool ManagedPackPage::runUpdateTask(InstanceTask* task)
{
    Q_ASSERT(task);

    const unique_qobject_ptr<Task> wrappedTask(APPLICATION->instances()->wrapInstanceTask(task));

    connect(wrappedTask.get(), &Task::failed, this,
            [this](const QString& reason) { CustomMessageBox::selectable(this, tr("Error"), reason, QMessageBox::Critical)->show(); });
    connect(wrappedTask.get(), &Task::succeeded, this, [this, task]() {
        QStringList warnings = task->warnings();
        if (warnings.count()) {
            CustomMessageBox::selectable(this, tr("Warnings"), warnings.join('\n'), QMessageBox::Warning)->show();
        }
    });

    ProgressDialog loadDialog(this);
    loadDialog.showSkipButton();
    loadDialog.execWithTask(wrappedTask.get());

    return wrappedTask->wasSuccessful();
}

void ManagedPackPage::suggestVersion()
{
    ui->updateButton->setText(tr("Update Pack"));
    ui->updateButton->setDisabled(false);
}

void ManagedPackPage::setFailState()
{
    qDebug() << "Setting fail state!";

    // We block signals here so that suggestVersion() doesn't get called, causing an assertion fail.
    ui->versionsComboBox->blockSignals(true);
    ui->versionsComboBox->clear();
    ui->versionsComboBox->addItem(tr("Failed to search for available versions."), {});
    ui->versionsComboBox->blockSignals(false);

    ui->changelogTextBrowser->setText(tr("Failed to request changelog data for this modpack."));

    ui->updateButton->setText(tr("Cannot update!"));
    ui->updateButton->setDisabled(true);

    ui->reloadButton->setVisible(true);
}

ModrinthManagedPackPage::ModrinthManagedPackPage(BaseInstance* inst, InstanceWindow* instanceWindow, QWidget* parent)
    : ManagedPackPage(inst, instanceWindow, parent)
{
    Q_ASSERT(inst->isManagedPack());
    connect(ui->versionsComboBox, &QComboBox::currentIndexChanged, this, &ModrinthManagedPackPage::suggestVersion);
    connect(ui->updateButton, &QPushButton::clicked, this, &ModrinthManagedPackPage::update);
    connect(ui->updateFromFileButton, &QPushButton::clicked, this, &ModrinthManagedPackPage::updateFromFile);
}

// MODRINTH
void ModrinthManagedPackPage::parseManagedPack()
{
    qDebug() << "Parsing Modrinth pack";

    // No need for the extra work because we already have everything we need.
    if (m_loaded) {
        return;
    }

    if (m_fetchJob && m_fetchJob->isRunning()) {
        m_fetchJob->abort();
    }

    ResourceAPI::Callback<QVector<ModPlatform::IndexedVersion>> callbacks{};
    m_pack = { .addonId = m_inst->getManagedPackID() };

    // Use default if no callbacks are set
    callbacks.onSucceed = [this](auto& doc) {
        m_pack.versions = doc;
        m_pack.versionsLoaded = true;

        // We block signals here so that suggestVersion() doesn't get called, causing an assertion fail.
        ui->versionsComboBox->blockSignals(true);
        ui->versionsComboBox->clear();
        ui->versionsComboBox->blockSignals(false);

        for (const auto& version : m_pack.versions) {
            QString name = version.getVersionDisplayString();

            // NOTE: the id from version isn't the same id in the modpack format spec...
            // e.g. HexMC's 4.4.0 has versionId 4.0.0 in the modpack index..............
            if (version.version == m_inst->getManagedPackVersionName()) {
                name = tr("%1 (Current)").arg(name);
            }

            ui->versionsComboBox->addItem(name, version.fileId);
        }

        suggestVersion();

        m_loaded = true;
    };
    callbacks.onFail = [this](const QString& /*reason*/, int) { setFailState(); };
    callbacks.onAbort = [this]() { setFailState(); };
    m_fetchJob = ModrinthAPI::get().getProjectVersions({ .pack = std::make_shared<ModPlatform::IndexedPack>(m_pack),
                                                         .mcVersions = {},
                                                         .loaders = {},
                                                         .resourceType = ModPlatform::ResourceType::Modpack,
                                                         .includeChangelog = true },
                                                       callbacks);

    ui->changelogTextBrowser->setText(tr("Fetching changelogs..."));

    m_fetchJob->start();
}

QString ModrinthManagedPackPage::url() const
{
    return "https://modrinth.com/mod/" + m_inst->getManagedPackID();
}

void ModrinthManagedPackPage::suggestVersion()
{
    auto index = ui->versionsComboBox->currentIndex();
    if (m_pack.versions.length() == 0) {
        setFailState();
        return;
    }
    auto version = m_pack.versions.at(index);

    ui->changelogTextBrowser->setHtml(StringUtils::htmlListPatch(markdownToHTML(version.changelog.toUtf8())));

    ManagedPackPage::suggestVersion();
}

/// @brief Called when the update task has completed.
/// Internally handles the closing of the instance window if the update was successful and shows a message box.
/// @param did_succeed Whether the update task was successful.
void ManagedPackPage::onUpdateTaskCompleted(bool didSucceed) const
{
    // Close the window if the update was successful
    if (didSucceed) {
        if (m_instanceWindow != nullptr) {
            m_instanceWindow->close();
        }

        CustomMessageBox::selectable(nullptr, tr("Update Successful"),
                                     tr("The instance updated to pack version %1 successfully.").arg(m_inst->getManagedPackVersionName()),
                                     QMessageBox::Information)
            ->show();
    } else {
        CustomMessageBox::selectable(
            nullptr, tr("Update Failed"),
            tr("The instance failed to update to pack version %1. Please check launcher logs for more information.")
                .arg(m_inst->getManagedPackVersionName()),
            QMessageBox::Critical)
            ->show();
    }
}

void ModrinthManagedPackPage::update()
{
    auto customURL = m_inst->settings()->get("ManagedPackURL").toString().trimmed();
    if (m_inst->getManagedPackID().isEmpty() && !customURL.isEmpty()) {
        updatePack(customURL, false);
        return;
    }
    auto index = ui->versionsComboBox->currentIndex();
    if (m_pack.versions.length() == 0) {
        setFailState();
        return;
    }
    auto version = m_pack.versions.at(index);

    updatePack(version.downloadUrl, true, version.fileId.toString(), version.version);
}

void ModrinthManagedPackPage::updateFromFile()
{
    auto output = QFileDialog::getOpenFileUrl(this, tr("Choose update file"), QDir::homePath(), tr("Modrinth pack") + " (*.mrpack *.zip)");
    if (output.isEmpty()) {
        return;
    }

    updatePack(output, false);
}

// FLAME
FlameManagedPackPage::FlameManagedPackPage(BaseInstance* inst, InstanceWindow* instanceWindow, QWidget* parent)
    : ManagedPackPage(inst, instanceWindow, parent)
{
    Q_ASSERT(inst->isManagedPack());
    connect(ui->versionsComboBox, &QComboBox::currentIndexChanged, this, &FlameManagedPackPage::suggestVersion);
    connect(ui->updateButton, &QPushButton::clicked, this, &FlameManagedPackPage::update);
    connect(ui->updateFromFileButton, &QPushButton::clicked, this, &FlameManagedPackPage::updateFromFile);
}

void FlameManagedPackPage::parseManagedPack()
{
    qDebug() << "Parsing Flame pack";

    // We need to tell the user to redownload the pack, since we didn't save the required info previously
    if (m_inst->getManagedPackID().isEmpty()) {
        setFailState();
        QString message =
            tr("<h1>Hey there!</h1>"
               "<h4>"
               "It seems like your Pack ID is null. This is because of a bug in older versions of the launcher.<br/>"
               "Unfortunately, we can't do the proper API requests without this information.<br/>"
               "<br/>"
               "So, in order for this feature to work, you will need to re-download the modpack from the built-in downloader.<br/>"
               "<br/>"
               "Don't worry though, it will ask you to update this instance instead, so you'll not lose this instance!"
               "</h4>");

        ui->changelogTextBrowser->setHtml(StringUtils::htmlListPatch(message));
        return;
    }

    // No need for the extra work because we already have everything we need.
    if (m_loaded) {
        return;
    }

    if (m_fetchJob && m_fetchJob->isRunning()) {
        m_fetchJob->abort();
    }

    QString id = m_inst->getManagedPackID();
    m_pack = { .addonId = id };

    ResourceAPI::Callback<QVector<ModPlatform::IndexedVersion>> callbacks{};

    // Use default if no callbacks are set
    callbacks.onSucceed = [this](auto& doc) {
        m_pack.versions = doc;
        m_pack.versionsLoaded = true;

        // We block signals here so that suggestVersion() doesn't get called, causing an assertion fail.
        ui->versionsComboBox->blockSignals(true);
        ui->versionsComboBox->clear();
        ui->versionsComboBox->blockSignals(false);

        for (const auto& version : m_pack.versions) {
            QString name = version.getVersionDisplayString();

            if (version.fileId == m_inst->getManagedPackVersionID().toInt()) {
                name = tr("%1 (Current)").arg(name);
            }

            ui->versionsComboBox->addItem(name, QVariant(version.fileId));
        }

        suggestVersion();

        m_loaded = true;
    };
    callbacks.onFail = [this](const QString& /*reason*/, int) { setFailState(); };
    callbacks.onAbort = [this]() { setFailState(); };
    m_fetchJob = FlameAPI::get().getProjectVersions({ .pack = std::make_shared<ModPlatform::IndexedPack>(m_pack),
                                                      .mcVersions = {},
                                                      .loaders = {},
                                                      .resourceType = ModPlatform::ResourceType::Modpack,
                                                      .includeChangelog = true },
                                                    callbacks);

    m_fetchJob->start();
}

QString FlameManagedPackPage::url() const
{
    // FIXME: We should display the websiteUrl field, but this requires doing the API request first :(
    return "https://www.curseforge.com/projects/" + m_inst->getManagedPackID();
}

void FlameManagedPackPage::suggestVersion()
{
    auto index = ui->versionsComboBox->currentIndex();
    if (m_pack.versions.length() == 0) {
        setFailState();
        return;
    }
    auto version = m_pack.versions.at(index);

    ui->changelogTextBrowser->setHtml(
        StringUtils::htmlListPatch(FlameAPI::getModFileChangelog(m_inst->getManagedPackID().toInt(), version.fileId.toInt())));

    ManagedPackPage::suggestVersion();
}

void FlameManagedPackPage::update()
{
    auto customURL = m_inst->settings()->get("ManagedPackURL").toString().trimmed();
    if (m_inst->getManagedPackID().isEmpty() && !customURL.isEmpty()) {
        updatePack(customURL, false);
        return;
    }
    auto index = ui->versionsComboBox->currentIndex();
    if (m_pack.versions.length() == 0) {
        setFailState();
        return;
    }
    auto version = m_pack.versions.at(index);

    updatePack(version.downloadUrl, true, version.fileId.toString(), version.version);
}

void FlameManagedPackPage::updateFromFile()
{
    auto output = QFileDialog::getOpenFileUrl(this, tr("Choose update file"), QDir::homePath(), tr("CurseForge pack") + " (*.zip)");
    if (output.isEmpty()) {
        return;
    }

    updatePack(output, false);
}

void ManagedPackPage::updateFromUrl()
{
    bool ok = false;
    auto input = QInputDialog::getText(this, tr("Update from URL"), tr("Enter the download URL of the modpack file:"), QLineEdit::Normal,
                                       QString(), &ok)
                     .trimmed();
    if (!ok || input.isEmpty()) {
        return;
    }

    auto url = QUrl::fromUserInput(input);
    if (!url.isValid() || (url.scheme() != "http" && url.scheme() != "https")) {
        CustomMessageBox::selectable(this, tr("Invalid URL"), tr("Please enter a valid HTTP(S) URL."), QMessageBox::Critical)->show();
        return;
    }

    updatePack(url, false);
}

void ManagedPackPage::updatePack(const QUrl& url, bool trusted, const QString& versionID, const QString& versionName)
{
    QString confirmMessage;
    if (versionName.isEmpty()) {
        confirmMessage =
            tr("You are about to update the modpack to a new version.\n"
               "Irreversible changes may be made to the instance's files.\n"
               "As such, it is strongly recommended to create a backup copy of the instance.\n\n"
               "Are you sure?");
    } else {
        confirmMessage = tr("You are about to update the modpack to version \"%1\".\n"
                            "Irreversible changes may be made to the instance's files.\n"
                            "As such, it is strongly recommended to create a backup copy of the instance.\n\n"
                            "Are you sure?")
                             .arg(!versionName.isEmpty() ? versionName : versionID);
    }

    auto response = CustomMessageBox::selectable(this, tr("Confirm Update"), confirmMessage, QMessageBox::Warning,
                                                 QMessageBox::Yes | QMessageBox::No, QMessageBox::No)
                        ->exec();
    if (response != QMessageBox::Yes) {
        return;
    }

    QMap<QString, QString> extraInfo;
    // NOTE: Don't use 'm_pack.id' here, since we didn't completely parse all the metadata for the pack, including this field.
    extraInfo.insert("pack_id", m_inst->getManagedPackID());
    extraInfo.insert("pack_version_id", versionID);
    extraInfo.insert("original_instance_id", m_inst->id());

    auto* extracted = new InstanceImportTask(url, trusted, this, std::move(extraInfo));

    if (versionName.isEmpty()) {
        extracted->setName(m_inst->name());
    } else {
        extracted->setOriginalName(m_inst->getManagedPackName(), versionName);
        extracted->setName(m_inst->name().replace(m_inst->getManagedPackVersionName(), versionName));
    }
    extracted->setGroup(APPLICATION->instances()->getInstanceGroup(m_inst->id()));
    extracted->setIcon(m_inst->iconKey());
    extracted->setConfirmUpdate(false);

    // Run our task then handle the result
    auto didSucceed = runUpdateTask(extracted);
    onUpdateTaskCompleted(didSucceed);
}
