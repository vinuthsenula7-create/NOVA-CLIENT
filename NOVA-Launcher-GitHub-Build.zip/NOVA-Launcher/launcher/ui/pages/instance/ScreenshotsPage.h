// SPDX-License-Identifier: GPL-3.0-only
/*
 *  Prism Launcher - Minecraft Launcher
 *  Copyright (c) 2022 Jamie Mansfield <jmansfield@cadixdev.org>
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, version 3.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 * This file incorporates work covered by the following copyright and
 * permission notice:
 *
 *      Copyright 2013-2021 MultiMC Contributors
 *
 *      Licensed under the Apache License, Version 2.0 (the "License");
 *      you may not use this file except in compliance with the License.
 *      You may obtain a copy of the License at
 *
 *          http://www.apache.org/licenses/LICENSE-2.0
 *
 *      Unless required by applicable law or agreed to in writing, software
 *      distributed under the License is distributed on an "AS IS" BASIS,
 *      WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *      See the License for the specific language governing permissions and
 *      limitations under the License.
 */

#pragma once

#include <QMainWindow>

#include "ui/pages/BasePage.h"

class QIdentityProxyModel;
class QItemSelection;
namespace Ui {
class ScreenshotsPage;
}

class ScreenshotsFSModel;

struct ScreenShot;
class ScreenshotList;

class ScreenshotsPage : public QMainWindow, public BasePage {
    Q_OBJECT

   public:
    explicit ScreenshotsPage(QString path, QWidget* parent = 0);
    virtual ~ScreenshotsPage();

    void openedImpl() override;

    enum { NothingDone = 0x42 };

    virtual bool eventFilter(QObject*, QEvent*) override;
    virtual QString displayName() const override { return tr("Screenshots"); }
    virtual QIcon icon() const override { return QIcon::fromTheme("screenshots"); }
    virtual QString id() const override { return "screenshots"; }
    virtual QString helpPage() const override { return "Screenshots-management"; }
    virtual bool apply() override { return !m_uploadActive; }
    void retranslate() override;

   protected:
    QMenu* createPopupMenu() override;

   private slots:
    void on_actionUpload_triggered();
    void on_actionCopy_Image_triggered() const;
    void on_actionCopy_File_s_triggered() const;
    void on_actionDelete_triggered();
    void on_actionRename_triggered() const;
    void on_actionView_Folder_triggered() const;
    void onItemActivated(QModelIndex) const;
    void onCurrentSelectionChanged(const QItemSelection& selected) const;
    void showContextMenu(const QPoint& pos);

   private:
    Ui::ScreenshotsPage* ui;
    std::shared_ptr<ScreenshotsFSModel> m_model;
    std::shared_ptr<QIdentityProxyModel> m_filterModel;
    QString m_folder;
    bool m_valid = false;
    bool m_uploadActive = false;
};
