// SPDX-License-Identifier: GPL-3.0-only
/*
 *  PolyMC - Minecraft Launcher
 *  Copyright (c) 2022 Jamie Mansfield <jmansfield@cadixdev.org>
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, version 3.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 * This file incorporates work covered by the following copyright and
 * permission notice:
 *
 *      Copyright 2013-2021 MultiMC Contributors
 *
 *      Licensed under the Apache License, Version 2.0 (the "License");
 *      you may not use this file except in compliance with the License.
 *      You may obtain a copy of the License at
 *
 *          http://www.apache.org/licenses/LICENSE-2.0
 *
 *      Unless required by applicable law or agreed to in writing, software
 *      distributed under the License is distributed on an "AS IS" BASIS,
 *      WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *      See the License for the specific language governing permissions and
 *      limitations under the License.
 */

#pragma once

#include "FtbFilterModel.h"
#include "FtbListModel.h"

#include <QWidget>

#include "Application.h"
#include "tasks/Task.h"
#include "ui/pages/BasePage.h"
#include "ui/pages/modplatform/ModpackProviderBasePage.h"

namespace Ui {
class FtbPage;
}

class NewInstanceDialog;

class FtbPage : public QWidget, public ModpackProviderBasePage {
    Q_OBJECT

   public:
    explicit FtbPage(NewInstanceDialog* dialog, QWidget* parent = 0);
    virtual ~FtbPage();
    virtual QString displayName() const override { return "FTB"; }
    virtual QIcon icon() const override { return QIcon::fromTheme("ftb_logo"); }
    virtual QString id() const override { return "ftb"; }
    virtual QString helpPage() const override { return "FTB-platform"; }
    virtual bool shouldDisplay() const override;
    void retranslate() override;

    void openedImpl() override;
    void closedImpl() override;

    bool eventFilter(QObject* watched, QEvent* event) override;

    /** Programatically set the term in the search bar. */
    virtual void setSearchTerm(QString) override;
    /** Get the current term in the search bar. */
    [[nodiscard]] virtual QString getSerachTerm() const override;

   private:
    void suggestCurrent();

   private slots:
    void triggerSearch();

    void onSortingSelectionChanged(QString selected);
    void onSelectionChanged(QModelIndex first, QModelIndex second);
    void onVersionSelectionChanged(QString selected);

   private:
    Ui::FtbPage* m_ui = nullptr;
    NewInstanceDialog* m_dialog = nullptr;
    Ftb::ListModel* m_listModel = nullptr;
    Ftb::FilterModel* m_filterModel = nullptr;

    FTB::Modpack m_selected;
    QString m_selectedVersion;

    bool m_initialised{ false };
};
