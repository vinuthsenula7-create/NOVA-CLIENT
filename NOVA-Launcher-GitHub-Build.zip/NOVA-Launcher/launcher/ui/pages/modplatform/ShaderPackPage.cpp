// SPDX-FileCopyrightText: 2023 flowln <flowlnlnln@gmail.com>
//
// SPDX-License-Identifier: GPL-3.0-only

#include "ShaderPackPage.h"
#include "ui_ResourcePage.h"

#include "ShaderPackModel.h"

#include "ui/dialogs/ResourceDownloadDialog.h"

#include <QRegularExpression>
#include <utility>

namespace {

ResourceDownload::ResourceDescriptor prepareShaderPackDescriptor()
{
    return {
        .helpPage = {},
        //: The singular version of 'shader packs'
        .resourceString = QObject::tr("shader pack"),
        //: The plural version of 'shader pack'
        .resourcesString = QObject::tr("shader packs"),
        .supportsFiltering = false,
        .isIndexed = true,
    };
}
}  // namespace
namespace ResourceDownload {

ShaderPackResourcePage::ShaderPackResourcePage(ResourceDownloadDialog* dialog,
                                               BaseInstance& instance,
                                               ResourceProviderData provider,
                                               const ResourceAPI* api)
    : ResourcePage(dialog, instance, prepareShaderPackDescriptor(), std::move(provider))
{
    m_model = new ShaderPackResourceModel(getDialog()->getBaseModel(), api, debugName(), metaEntryBase());
    m_ui->packView->setModel(m_model);

    addSortings();

    // sometimes Qt just ignores virtual slots and doesn't work as intended it seems,
    // so it's best not to connect them in the parent's constructor...
    connect(m_model, &ResourceModel::versionListUpdated, this, &ResourcePage::versionListUpdated);
    connect(m_model, &ResourceModel::projectInfoUpdated, this, &ResourcePage::updateUi);
    connect(m_model, &QAbstractListModel::modelReset, this, &ResourcePage::modelReset);

    connect(m_ui->sortByBox, &QComboBox::currentIndexChanged, this, &ShaderPackResourcePage::triggerSearch);
    connect(m_ui->packView->selectionModel(), &QItemSelectionModel::currentChanged, this, &ShaderPackResourcePage::onSelectionChanged);
    connect(m_ui->versionSelectionBox, &QComboBox::currentIndexChanged, this, &ShaderPackResourcePage::onVersionSelectionChanged);
    connect(m_ui->resourceSelectionButton, &QPushButton::clicked, this, &ShaderPackResourcePage::onResourceSelected);

    m_ui->packDescription->setMetaEntry(metaEntryBase());
}

/******** Callbacks to events in the UI (set up in the derived classes) ********/

void ShaderPackResourcePage::triggerSearch()
{
    m_ui->packView->selectionModel()->setCurrentIndex({}, QItemSelectionModel::SelectionFlag::ClearAndSelect);
    m_ui->packView->clearSelection();
    m_ui->packDescription->clear();
    m_ui->versionSelectionBox->clear();

    updateSelectionButton();

    static_cast<ShaderPackResourceModel*>(m_model)->searchWithTerm(getSearchTerm(), m_ui->sortByBox->currentData().toUInt());
    m_fetchProgress.watch(m_model->activeSearchJob().get());
}

}  // namespace ResourceDownload
