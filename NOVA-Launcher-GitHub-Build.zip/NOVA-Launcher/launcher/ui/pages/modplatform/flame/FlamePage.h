// SPDX-License-Identifier: GPL-3.0-only
/*
 *  Prism Launcher - Minecraft Launcher
 *  Copyright (c) 2022 Jamie Mansfield <jmansfield@cadixdev.org>
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, version 3.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 * This file incorporates work covered by the following copyright and
 * permission notice:
 *
 *      Copyright 2013-2021 MultiMC Contributors
 *
 *      Licensed under the Apache License, Version 2.0 (the "License");
 *      you may not use this file except in compliance with the License.
 *      You may obtain a copy of the License at
 *
 *          http://www.apache.org/licenses/LICENSE-2.0
 *
 *      Unless required by applicable law or agreed to in writing, software
 *      distributed under the License is distributed on an "AS IS" BASIS,
 *      WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *      See the License for the specific language governing permissions and
 *      limitations under the License.
 */

#pragma once

#include <QWidget>

#include <QTimer>
#include "modplatform/ModIndex.h"
#include "ui/pages/modplatform/ModpackProviderBasePage.h"
#include "ui/widgets/ModFilterWidget.h"
#include "ui/widgets/ProgressWidget.h"

namespace Ui {
class FlamePage;
}

class NewInstanceDialog;

namespace Flame {
class ListModel;
}

class FlamePage : public QWidget, public ModpackProviderBasePage {
    Q_OBJECT

   public:
    explicit FlamePage(NewInstanceDialog* dialog, QWidget* parent = 0);
    ~FlamePage() override;
    QString displayName() const override { return "CurseForge"; }
    QIcon icon() const override { return QIcon::fromTheme("flame"); }
    QString id() const override { return "flame"; }
    QString helpPage() const override { return "Flame-platform"; }
    bool shouldDisplay() const override;
    void retranslate() override;

    void updateUi();

    void openedImpl() override;

    /** Programatically set the term in the search bar. */
    void setSearchTerm(QString /*unused*/) override;
    /** Get the current term in the search bar. */
    QString getSerachTerm() const override;

   private:
    void suggestCurrent();

   private slots:
    void triggerSearch();
    void onSelectionChanged(QModelIndex curr, QModelIndex prev);
    void onVersionSelectionChanged(int index);
    void createFilterWidget();

   private:
    Ui::FlamePage* m_ui = nullptr;
    NewInstanceDialog* m_dialog = nullptr;
    Flame::ListModel* m_listModel = nullptr;
    ModPlatform::IndexedPack::Ptr m_current;

    int m_selectedVersionIndex = -1;

    ProgressWidget m_fetchProgress;

    // Used to do instant searching with a delay to cache quick changes
    QTimer m_searchTimer;

    std::unique_ptr<ModFilterWidget> m_filterWidget;
    Task::Ptr m_categoriesTask;
    Task::Ptr m_job;
    Task::Ptr m_extraJob;
};
