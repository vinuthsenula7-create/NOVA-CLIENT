// SPDX-License-Identifier: GPL-3.0-only
/*
 *  Prism Launcher - Minecraft Launcher
 *  Copyright (c) 2022 Jamie Mansfield <jmansfield@cadixdev.org>
 *  Copyright (c) 2022 dada513 <dada513@protonmail.com>
 *  Copyright (C) 2022 Tayou <git@tayou.org>
 *  Copyright (C) 2024 TheKodeToad <TheKodeToad@proton.me>
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, version 3.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 * This file incorporates work covered by the following copyright and
 * permission notice:
 *
 *      Copyright 2013-2021 MultiMC Contributors
 *
 *      Licensed under the Apache License, Version 2.0 (the "License");
 *      you may not use this file except in compliance with the License.
 *      You may obtain a copy of the License at
 *
 *          http://www.apache.org/licenses/LICENSE-2.0
 *
 *      Unless required by applicable law or agreed to in writing, software
 *      distributed under the License is distributed on an "AS IS" BASIS,
 *      WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *      See the License for the specific language governing permissions and
 *      limitations under the License.
 */

#include "LauncherPage.h"
#include "ui_LauncherPage.h"

#include <QDir>
#include <QFileDialog>
#include <QMenuBar>
#include <QMessageBox>
#include <QTextCharFormat>

#include <FileSystem.h>
#include "Application.h"
#include "BuildConfig.h"
#include "DesktopServices.h"
#include "Json.h"
#include "settings/SettingsObject.h"
#include "ui/themes/ITheme.h"
#include "ui/themes/ThemeManager.h"
#include "updater/ExternalUpdater.h"

#include <QApplication>
#include <QProcess>

// FIXME: possibly move elsewhere
enum InstSortMode {
    // Sort alphabetically by name.
    Sort_Name,
    // Sort by which instance was launched most recently.
    Sort_LastLaunch,
    // Sort by which instance has the most playtime.
    Sort_Playtime,
};

LauncherPage::LauncherPage(QWidget* parent) : QWidget(parent), ui(new Ui::LauncherPage)
{
    ui->setupUi(this);

    ui->sortingModeGroup->setId(ui->sortByNameBtn, Sort_Name);
    ui->sortingModeGroup->setId(ui->sortLastLaunchedBtn, Sort_LastLaunch);
    ui->sortingModeGroup->setId(ui->sortByPlaytimeBtn, Sort_Playtime);

    loadSettings();

    ui->updateSettingsBox->setHidden(!APPLICATION->updater());
}

LauncherPage::~LauncherPage()
{
    delete ui;
}

bool LauncherPage::apply()
{
    applySettings();
    return true;
}

bool LauncherPage::confirmInstanceDirPath(const QString& rawDir, const QString& cookedDir)
{
    if (FS::checkProblemticPathJava(QDir(cookedDir))) {
        QMessageBox warning;
        warning.setText(
            tr("You're trying to specify an instance folder which\'s path "
               "contains at least one \'!\'. "
               "Java is known to cause problems if that is the case, your "
               "instances (probably) won't start!"));
        warning.setInformativeText(
            tr("Do you really want to use this path? "
               "Selecting \"No\" will close this and not alter your instance path."));
        warning.setStandardButtons(QMessageBox::Ok | QMessageBox::Cancel);
        if (warning.exec() != QMessageBox::Ok)
            return false;
    } else if (DesktopServices::isFlatpak() && rawDir.startsWith("/run/user")) {
        QMessageBox warning;
        warning.setText(tr("You're trying to specify an instance folder "
                           "which was granted temporarily via Flatpak.\n"
                           "This is known to cause problems. "
                           "After a restart the launcher might break, "
                           "because it will no longer have access to that directory.\n\n"
                           "Granting %1 access to it via Flatseal is recommended.")
                            .arg(BuildConfig.LAUNCHER_DISPLAYNAME));
        warning.setInformativeText(tr("Do you want to proceed anyway?"));
        warning.setStandardButtons(QMessageBox::Ok | QMessageBox::Cancel);
        if (warning.exec() != QMessageBox::Ok)
            return false;
    }
    return true;
}

void LauncherPage::on_instDirBrowseBtn_clicked()
{
    QString rawDir = QFileDialog::getExistingDirectory(this, tr("Instance Folder"), ui->instDirTextBox->text());
    if (!rawDir.isEmpty() && QDir(rawDir).exists()) {
        QString cookedDir = FS::NormalizePath(rawDir);
        if (confirmInstanceDirPath(rawDir, cookedDir))
            ui->instDirTextBox->setText(cookedDir);
    }
}

void LauncherPage::on_addInstDirBtn_clicked()
{
    QString rawDir = QFileDialog::getExistingDirectory(this, tr("Additional Instance Folder"));
    if (rawDir.isEmpty() || !QDir(rawDir).exists())
        return;

    QString cookedDir = FS::NormalizePath(rawDir);
    if (cookedDir == FS::NormalizePath(ui->instDirTextBox->text())) {
        QMessageBox::warning(this, tr("Duplicate directory"), tr("This is already your primary instance directory."));
        return;
    }

    if (!ui->additionalInstDirsList->findItems(cookedDir, Qt::MatchFixedString).isEmpty()) {
        QMessageBox::warning(this, tr("Duplicate directory"), tr("This directory has already been added."));
        return;
    }

    if (!confirmInstanceDirPath(rawDir, cookedDir))
        return;

    ui->additionalInstDirsList->addItem(cookedDir);
}

void LauncherPage::on_removeInstDirBtn_clicked()
{
    qDeleteAll(ui->additionalInstDirsList->selectedItems());
}

void LauncherPage::on_iconsDirBrowseBtn_clicked()
{
    QString rawDir = QFileDialog::getExistingDirectory(this, tr("Icons Folder"), ui->iconsDirTextBox->text());

    // do not allow current dir - it's dirty. Do not allow dirs that don't exist
    if (!rawDir.isEmpty() && QDir(rawDir).exists()) {
        QString cookedDir = FS::NormalizePath(rawDir);
        ui->iconsDirTextBox->setText(cookedDir);
    }
}

void LauncherPage::on_modsDirBrowseBtn_clicked()
{
    QString rawDir = QFileDialog::getExistingDirectory(this, tr("Mods Folder"), ui->modsDirTextBox->text());

    // do not allow current dir - it's dirty. Do not allow dirs that don't exist
    if (!rawDir.isEmpty() && QDir(rawDir).exists()) {
        QString cookedDir = FS::NormalizePath(rawDir);
        ui->modsDirTextBox->setText(cookedDir);
    }
}

void LauncherPage::on_downloadsDirBrowseBtn_clicked()
{
    QString rawDir = QFileDialog::getExistingDirectory(this, tr("Downloads Folder"), ui->downloadsDirTextBox->text());

    if (!rawDir.isEmpty() && QDir(rawDir).exists()) {
        QString cookedDir = FS::NormalizePath(rawDir);
        ui->downloadsDirTextBox->setText(cookedDir);
    }
}

void LauncherPage::on_javaDirBrowseBtn_clicked()
{
    QString rawDir = QFileDialog::getExistingDirectory(this, tr("Java Folder"), ui->javaDirTextBox->text());

    if (!rawDir.isEmpty() && QDir(rawDir).exists()) {
        QString cookedDir = FS::NormalizePath(rawDir);
        ui->javaDirTextBox->setText(cookedDir);
    }
}

void LauncherPage::on_templateDirBrowseBtn_clicked()
{
    QString rawDir = QFileDialog::getExistingDirectory(this, tr("Instance Template Folder"), ui->templateDirTextBox->text());

    if (!rawDir.isEmpty() && QDir(rawDir).exists()) {
        QString cookedDir = FS::NormalizePath(rawDir);
        ui->templateDirTextBox->setText(cookedDir);
    }
}

void LauncherPage::on_skinsDirBrowseBtn_clicked()
{
    QString rawDir = QFileDialog::getExistingDirectory(this, tr("Skins Folder"), ui->skinsDirTextBox->text());

    // do not allow current dir - it's dirty. Do not allow dirs that don't exist
    if (!rawDir.isEmpty() && QDir(rawDir).exists()) {
        QString cookedDir = FS::NormalizePath(rawDir);
        ui->skinsDirTextBox->setText(cookedDir);
    }
}

void LauncherPage::on_metadataEnableBtn_clicked()
{
    ui->metadataWarningLabel->setHidden(ui->metadataEnableBtn->isChecked());
}

void LauncherPage::applySettings()
{
    auto* s = APPLICATION->settings();

    // Updates
    if (APPLICATION->updater()) {
        APPLICATION->updater()->setAutomaticallyChecksForUpdates(ui->autoUpdateCheckBox->isChecked());
        APPLICATION->updater()->setUpdateCheckInterval(ui->updateIntervalSpinBox->value() * 3600);
    }

    s->set("MenuBarInsteadOfToolBar", ui->preferMenuBarCheckBox->isChecked());

    s->set("NumberOfConcurrentTasks", ui->numberOfConcurrentTasksSpinBox->value());
    s->set("NumberOfConcurrentDownloads", ui->numberOfConcurrentDownloadsSpinBox->value());
    s->set("NetworkRetryLimit", ui->networkRetryLimitSpinBox->value());
    s->set("RequestTimeout", ui->timeoutSecondsSpinBox->value());

    // Console settings
    s->set("ConsoleMaxLines", ui->lineLimitSpinBox->value());
    s->set("ConsoleOverflowStop", ui->checkStopLogging->checkState() != Qt::Unchecked);

    // Folders
    // TODO: Offer to move instances to new instance folder.
    s->set("InstanceDir", ui->instDirTextBox->text());
    {
        QStringList additionalDirs;
        for (int i = 0; i < ui->additionalInstDirsList->count(); ++i) {
            additionalDirs << ui->additionalInstDirsList->item(i)->text();
        }
        s->set("AdditionalInstanceDirs", additionalDirs);
    }
    s->set("CentralModsDir", ui->modsDirTextBox->text());
    s->set("IconsDir", ui->iconsDirTextBox->text());
    s->set("DownloadsDir", ui->downloadsDirTextBox->text());
    s->set("SkinsDir", ui->skinsDirTextBox->text());
    s->set("JavaDir", ui->javaDirTextBox->text());
    s->set("TemplateDir", ui->templateDirTextBox->text());
    s->set("DownloadsDirWatchRecursive", ui->downloadsDirWatchRecursiveCheckBox->isChecked());
    s->set("MoveModsFromDownloadsDir", ui->downloadsDirMoveCheckBox->isChecked());

    // Instance
    auto sortMode = (InstSortMode)ui->sortingModeGroup->checkedId();
    switch (sortMode) {
        case Sort_LastLaunch:
            s->set("InstSortMode", "LastLaunch");
            break;
        case Sort_Playtime:
            s->set("InstSortMode", "Playtime");
            break;
        case Sort_Name:
        default:
            s->set("InstSortMode", "Name");
            break;
    }

    if (ui->askToRenameDirBtn->isChecked()) {
        s->set("InstRenamingMode", "AskEverytime");
    } else if (ui->alwaysRenameDirBtn->isChecked()) {
        s->set("InstRenamingMode", "PhysicalDir");
    } else if (ui->neverRenameDirBtn->isChecked()) {
        s->set("InstRenamingMode", "MetadataOnly");
    }

    s->set("EditInstanceOnDoubleClick", ui->editInstanceOnDoubleClick->isChecked());

    // Mods
    s->set("ModMetadataDisabled", !ui->metadataEnableBtn->isChecked());
    s->set("ModDependenciesDisabled", !ui->dependenciesEnableBtn->isChecked());
    s->set("ShowModIncompat", ui->showModIncompatCheckBox->isChecked());
    s->set("SkipModpackUpdatePrompt", !ui->modpackUpdatePromptBtn->isChecked());
    s->set("DownloadGameFilesDuringInstanceCreation", ui->downloadGameFilesBtn->isChecked());

    switch (ui->modUpdateChannelComboBox->currentIndex()) {
        case 1:
            s->set("ModUpdateReleaseTypes", "[\"release\"]");
            break;
        case 2:
            s->set("ModUpdateReleaseTypes", "[\"release\", \"beta\"]");
            break;
        case 0:
        default:
            s->set("ModUpdateReleaseTypes", "[]");
            break;
    }
}
void LauncherPage::loadSettings()
{
    auto* s = APPLICATION->settings();
    // Updates
    if (APPLICATION->updater()) {
        ui->autoUpdateCheckBox->setChecked(APPLICATION->updater()->getAutomaticallyChecksForUpdates());
        ui->updateIntervalSpinBox->setValue(APPLICATION->updater()->getUpdateCheckInterval() / 3600);
    }

    ui->preferMenuBarCheckBox->setChecked(s->get("MenuBarInsteadOfToolBar").toBool());

    ui->numberOfConcurrentTasksSpinBox->setValue(s->get("NumberOfConcurrentTasks").toInt());
    ui->numberOfConcurrentDownloadsSpinBox->setValue(s->get("NumberOfConcurrentDownloads").toInt());
    ui->networkRetryLimitSpinBox->setValue(s->get("NetworkRetryLimit").toInt());
    ui->timeoutSecondsSpinBox->setValue(s->get("RequestTimeout").toInt());

    // Console settings
    ui->lineLimitSpinBox->setValue(s->get("ConsoleMaxLines").toInt());
    ui->checkStopLogging->setChecked(s->get("ConsoleOverflowStop").toBool());

    // Folders
    ui->instDirTextBox->setText(s->get("InstanceDir").toString());
    ui->additionalInstDirsList->clear();
    ui->additionalInstDirsList->addItems(s->get("AdditionalInstanceDirs").toStringList());
    ui->modsDirTextBox->setText(s->get("CentralModsDir").toString());
    ui->iconsDirTextBox->setText(s->get("IconsDir").toString());
    ui->downloadsDirTextBox->setText(s->get("DownloadsDir").toString());
    ui->skinsDirTextBox->setText(s->get("SkinsDir").toString());
    ui->javaDirTextBox->setText(s->get("JavaDir").toString());
    ui->templateDirTextBox->setText(s->get("TemplateDir").toString());
    ui->downloadsDirWatchRecursiveCheckBox->setChecked(s->get("DownloadsDirWatchRecursive").toBool());
    ui->downloadsDirMoveCheckBox->setChecked(s->get("MoveModsFromDownloadsDir").toBool());

    // Instance
    QString sortMode = s->get("InstSortMode").toString();
    if (sortMode == "LastLaunch") {
        ui->sortLastLaunchedBtn->setChecked(true);
    } else if (sortMode == "Playtime") {
        ui->sortByPlaytimeBtn->setChecked(true);
    } else {
        ui->sortByNameBtn->setChecked(true);
    }

    ui->editInstanceOnDoubleClick->setChecked(s->get("EditInstanceOnDoubleClick").toBool());

    QString renamingMode = s->get("InstRenamingMode").toString();
    ui->askToRenameDirBtn->setChecked(renamingMode == "AskEverytime");
    ui->alwaysRenameDirBtn->setChecked(renamingMode == "PhysicalDir");
    ui->neverRenameDirBtn->setChecked(renamingMode == "MetadataOnly");

    // Mods
    ui->metadataEnableBtn->setChecked(!s->get("ModMetadataDisabled").toBool());
    ui->metadataWarningLabel->setHidden(ui->metadataEnableBtn->isChecked());
    ui->dependenciesEnableBtn->setChecked(!s->get("ModDependenciesDisabled").toBool());
    ui->showModIncompatCheckBox->setChecked(s->get("ShowModIncompat").toBool());
    ui->modpackUpdatePromptBtn->setChecked(!s->get("SkipModpackUpdatePrompt").toBool());
    ui->downloadGameFilesBtn->setChecked(s->get("DownloadGameFilesDuringInstanceCreation").toBool());

    const auto releaseTypesSetting = Json::toStringList(s->get("ModUpdateReleaseTypes").toString());
    if (releaseTypesSetting.size() == 1 && releaseTypesSetting.contains("release", Qt::CaseInsensitive)) {
        ui->modUpdateChannelComboBox->setCurrentIndex(1);
    } else if (releaseTypesSetting.size() == 2 && releaseTypesSetting.contains("release", Qt::CaseInsensitive) &&
               releaseTypesSetting.contains("beta", Qt::CaseInsensitive)) {
        ui->modUpdateChannelComboBox->setCurrentIndex(2);
    } else {
        ui->modUpdateChannelComboBox->setCurrentIndex(0);
    }
}

void LauncherPage::retranslate()
{
    ui->retranslateUi(this);
}
