// SPDX-License-Identifier: GPL-3.0-only
/*
 *  Prism Launcher - Minecraft Launcher
 *  Copyright (C) 2024 Tayou <git@tayou.org>
 *  Copyright (C) 2024 TheKodeToad <TheKodeToad@proton.me>
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, version 3.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 * This file incorporates work covered by the following copyright and
 * permission notice:
 *
 *      Copyright 2013-2021 MultiMC Contributors
 *
 *      Licensed under the Apache License, Version 2.0 (the "License");
 *      you may not use this file except in compliance with the License.
 *      You may obtain a copy of the License at
 *
 *          http://www.apache.org/licenses/LICENSE-2.0
 *
 *      Unless required by applicable law or agreed to in writing, software
 *      distributed under the License is distributed on an "AS IS" BASIS,
 *      WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *      See the License for the specific language governing permissions and
 *      limitations under the License.
 */
#include "DarkTheme.h"

#include <QObject>

QString DarkTheme::id()
{
    return "dark";
}

QString DarkTheme::name()
{
    return QObject::tr("Dark");
}

QPalette DarkTheme::colorScheme()
{
    QPalette darkPalette;
    darkPalette.setColor(QPalette::Window, QColor(25, 24, 43));
    darkPalette.setColor(QPalette::WindowText, Qt::white);
    darkPalette.setColor(QPalette::Base, QColor(17, 18, 34));
    darkPalette.setColor(QPalette::AlternateBase, QColor(29, 29, 51));
    darkPalette.setColor(QPalette::ToolTipBase, QColor(124, 92, 255));
    darkPalette.setColor(QPalette::ToolTipText, Qt::white);
    darkPalette.setColor(QPalette::Text, Qt::white);
    darkPalette.setColor(QPalette::Button, QColor(34, 32, 58));
    darkPalette.setColor(QPalette::ButtonText, Qt::white);
    darkPalette.setColor(QPalette::BrightText, Qt::red);
    darkPalette.setColor(QPalette::Link, QColor(56, 189, 248));
    darkPalette.setColor(QPalette::Highlight, QColor(124, 92, 255));
    darkPalette.setColor(QPalette::HighlightedText, Qt::black);
    darkPalette.setColor(QPalette::PlaceholderText, Qt::darkGray);
    return fadeInactive(darkPalette, fadeAmount(), fadeColor());
}

double DarkTheme::fadeAmount()
{
    return 0.5;
}

QColor DarkTheme::fadeColor()
{
    return QColor(25, 24, 43);
}

bool DarkTheme::hasStyleSheet()
{
    return false;
}

QString DarkTheme::appStyleSheet()
{
    return QStringLiteral(R"qss(
        QToolTip {
            color: #f4f2ff;
            background-color: #17162b;
            border: 1px solid #7c5cff;
            padding: 6px;
        }
        QPushButton {
            border: 1px solid #45406d;
            border-radius: 6px;
            padding: 6px 12px;
            background-color: #24213f;
            color: #f4f2ff;
        }
        QPushButton:hover { background-color: #342d60; border-color: #8b75ff; }
        QPushButton:pressed { background-color: #51418f; }
        QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox, QPlainTextEdit, QTextEdit {
            background-color: #111222;
            color: #f4f2ff;
            border: 1px solid #393653;
            border-radius: 5px;
            padding: 4px;
            selection-background-color: #7c5cff;
        }
        QHeaderView::section {
            background-color: #211f39;
            color: #dcd7ff;
            border: 0;
            border-bottom: 1px solid #45406d;
            padding: 6px;
        }
        QMenu { background-color: #17162b; color: #f4f2ff; border: 1px solid #45406d; }
        QMenu::item:selected { background-color: #51418f; }
        QProgressBar { border: 1px solid #45406d; border-radius: 4px; text-align: center; }
        QProgressBar::chunk { background-color: #7c5cff; border-radius: 3px; }
    )qss");
}

QString DarkTheme::tooltip()
{
    return "";
}
