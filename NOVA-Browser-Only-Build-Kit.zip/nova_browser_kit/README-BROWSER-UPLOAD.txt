NOVA LAUNCHER — BROWSER-ONLY GITHUB BUILD

You do NOT need GitHub Desktop, Visual Studio, CMake, Qt, or a C++ compiler on your PC.
GitHub will compile NOVA on its Windows runner.

PART A — MAKE A REPOSITORY
1. Sign in at https://github.com
2. Open https://github.com/new
3. Repository name: NOVA-Launcher
4. Choose Public (GitHub Actions standard runners are free for public repositories).
5. Leave “Add a README file” unchecked, then click Create repository.

PART B — UPLOAD THE SOURCE ZIP IN YOUR BROWSER
1. On the new repository page, click “Add file” > “Upload files”.
2. Upload the file named NOVA-Launcher-GitHub-Build.zip from this kit.
3. Scroll down, enter commit message: Add NOVA source ZIP
4. Click “Commit changes”.

IMPORTANT: Upload the ZIP file itself to the repository ROOT. Do not extract it on GitHub.
The workflow will extract it on GitHub's Windows build computer.

PART C — ADD THE BUILD WORKFLOW IN THE BROWSER
1. On your repository page, click “Add file” > “Create new file”.
2. In the filename box at the top, enter exactly:
   .github/workflows/build-nova-from-zip.yml
3. Open the file build-nova-from-zip.yml from this kit in Notepad.
4. Copy all its contents and paste them into GitHub's editor.
5. Click “Commit changes” (green button), then confirm “Commit changes”.

PART D — START THE BUILD
1. Open the repository's Actions tab.
2. In the left sidebar, click “Build NOVA Launcher for Windows”.
3. Click “Run workflow” on the right.
4. Keep Release selected and click the green “Run workflow” button.
5. Wait for the workflow to finish. The first build can take a long time because it downloads and compiles dependencies.
6. If it succeeds, open the completed run and scroll to Artifacts.
7. Download NOVA-Launcher-Windows and extract it on your PC.
8. Run nova-launcher.exe. Keep the other extracted files and folders beside the EXE.

IF IT FAILS
Open the failed workflow run, click the step with a red X, and copy the error text. You can paste the error into ChatGPT for help.

NOTES
- This builds source code on GitHub; it does not guarantee the build will succeed. Dependency versions or upstream build changes can cause errors.
- The ZIP contains a fork of Prism Launcher. Preserve its license and copyright notices. If you distribute your build, comply with GPL-3.0-only and provide the corresponding source code.
- The GitHub Actions artifact is retained for 14 days by this workflow.
